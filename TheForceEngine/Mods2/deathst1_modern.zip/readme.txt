================================================================
Title                   : Operation: Evasive Action   
Filename                : deathstr.GOB
Author                  : Andrew Emmons
Email Address           : aemmons@atlsci.com
Misc. Author Info       : www.atlsci.com/~aemmons

Description             : "An entire legion of my best troops await them..."
			   In 'The return of the Jedi", the Emperor was 
		           refering to a squad of Dark Troopers. They were
                           waiting on the Death Star, ready to launch
		           when news of trouble came from Endor. 
			   As Kyle, you are assigned to infiltrate the Death Star
                           and eliminate the Dark Troopers before they launch and 
                           destroy whatever hope the rebellion has of defeating the
                           Emporer.

Additional Credits to   : Lucasarts
================================================================

* Play Information *

Level(s) replaced       : SECBASE
Difficulty Settings     : Not implemented ( USE MED )
New BMs                 : No
New FMEs                : No
New WAXs                : No
New 3DOs                : No
New VOCs                : No
New GMDs                : No

* Construction *

Base                    : New level from scratch
Editor(s) used          : DFUSE
Known Bugs              : 


* Copyright / Permissions *

Authors MAY use this level as a base to build additional
levels.  

You may do whatever you want with this file.

