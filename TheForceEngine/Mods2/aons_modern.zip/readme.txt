================================================================
Title                   : Assasssination at Nar Shaddaa - Boba Fett Episode I Version 1.5
Filename                : assassin.ZIP
Author                  : Barry Brien
Email Address           : onthestreet@hotmail.com
Misc. Author Info       : Coming nearly 4 years later, this is an attempt to once and for all fix the bugs that were causing 			  this level to crash. Hopefully I got them this time.

Description             : You play the part of Boba Fett. You have just been hired by your long time client Jabba The Hutt
to take care of some business in the city of Nar Shaddaa. It seems an arrogant young relative of his named Priga has been
muscling in on Jabba's trade. Priga's been making quite a name for himself on the Smugglers Moon, and Jabba is not happy. 
Rather than share his trade with Priga, Jabba has decided that the galaxy isn't big enough for the both of them. Jabba has 
hired you to assassinate Priga the Hutt. 
But why hire the legendary Boba Fett just to pick off some cocky little upstart? Well Jabba knows that for all his talk, 
Priga is careful. He has built himself a safe little citadel in a quiet part of the city. Security is high, and it won't 
be easy. You are the only man for the job...

Due to the nature of this operation, you will be keeping to quieter parts of the city wherever possible. The last thing you
want is a full scale war on your hands. You're not Kyle Katarn after all, and one man warfare is not your fort�. Stealth is 
the name of the game. After you land in our secure area your ship will be guided on a pre-programmed autopilot to a 
safe-house outside the city until the job has been done. From our secure area you will be able to make your way to a service
centre. The centre is run by a small garrison of imperials, but don't expect any favours - sources say that they're on
Priga's payroll. They turn a blind eye to his illicit dealings in return for a small cut of the profit. Apart from this,
the area is off limits to the public, and any imps that sight you will not stop to ask questions.
You will be using a set of service elevators that are for authorised use only. In order to use these elevators you need to 
find a way to get past their secutiry system. There should be an emergency
override system not too far away. Find this override system and activate it. Then you will have access to the different
levels of the city.
 
Next you will need locate Priga's citadel. This will not be easy. Priga doesn't share Jabba's flamboyant tastes. His Citadel
is somewhere on 'Docking level 1' Don't expect to be able to walk in through the front door though.
Look for an alternative means of entry
Little is known about Priga's base, but be careful, he may already be alerted to your presence. Watch out for traps
and mercenaries. Once you find Priga waste no time in disposing of him.
Once the deed is done make your way to the rooftops for rendezvous with your ship. When you reach the rooftops Slave 1
should be waiting for you. Waste no time in fleeing the city.

Objectives		:  Override the elevator security system in the service centre.
			   Breach Priga the Hutt's citadel
			   Assassinate Priga the Hutt 
			   Rendezvous with Slave 1 at the highest point in the city you can find.	 


NOTES AND TIPS:

This is not an Imperial base, nor enemy's dungeon. This is a city, populated with civilians. Some civilians will attack you, but not all of them. Some civilians will attack only when provoked,
and some will just cower in fear. As well as this there is an imperial presence in the city. They will only fire at you in defence (i.e. if you fire first, or come too close to them). However, some areas are off limits and if an imperial notices you tresspassing he'll attack without hesitation.

SHOPS: I have implemented a money system in this level. The player starts off with 200 credits. Once spent, the money is gone, In other words there is no way to earn/gain money in the level, except for com-links if you feel like asking Jabba to send you more (very unadvisable). Around the city the player will find shops. For simplicity these shops will specialise in only 1 product each. Beware, some shops will be more useful than others. Make sure you know what you're buying before you part with your credits.
That product will be on sale for a specific price and the player will be limited to making only 3 purchases in any one shop. Each time the player makes a purchase (press space bar at counter) his amount of money will decrease. When the player has no money left, he/she can make no more purchases. It is possible to steal from some shops, but I strongly advise AGAINST this course of action. If the player fires a weapon inside a shop he/she will be unable to make any purchases in that shop.
Items available will be mainly medkits, shields and weaponry. Prices will always be stated before purchase. Once spacebar is hit the transaction is made, and even if you don't pick up your purchase from the counter, your money is spent. THERE ARE NO REFUNDS. Therefore, there isn't much point in buying a medkit if your health is full, unless you intend to come back later to get it. If the player purchases an item he/she cannot pick up (i.e. a medikit when health is at full) the item will flash, indicating that you have cannot carry any more of those units. The items will remain on the counter, and you may retrieve them at a later stage if you need to.  


Additional Credits to   : Matthias von Herrmann, Ajay Huff, Chris Landrum, Peter Klassen, Don Sielke, Kevin Buscemi, Rob Bankey, Richard Snodgrass, Gary Belisle, Al MacDonald, Greg Nickles, Dan Monceaux, Llyren + Jedi Cheddar, Ales Ptacek, Allen Newman

Special thanks to Patrick Haslow and Matthew Hallaron who both went out of their way to help me with this project.

Special thanks also to Geoffrey Simpson and Paul Fenney for testing the mission and providing valuable advise.

Extra special thanks to everybody at df-21 for their patience and assistance with trying to get this level bug-free

Place assassin.bat assassin.gob and assassin.lfd in your \dark dir and run assassin.bat
Don't forget to read the textcrawl.

================================================================

* Play Information *

Level replaced          : jabship
Difficulty Settings     : Yes
New BMs                 : Yes 
New FMEs                : Yes
New WAXs                : Yes
New 3DOs                : Yes 
New VOCs                : Yes
New GMDs                : No
New VUEs                : Yes 
New Briefings           : Yes
New Cutscenes           : Yes

* Construction *

Base                    : Assassination on Nar Shaddaa Ver 1.1
Editor(s) used          : WDFUSE 2.00
Known Bugs              : Slight Homming in areas, also sometimes when you purchase items you get 2 instead 			  			  of one - it's not a special offer, as you end up paying for both. :)
		          Your HUD won't update as you complete mission goals, so when you complete a goal, it will tell you 				  so in the upper left-hand corner of the screen.
			  If you abort mission the program crashes. It also crashes when you exit to dos.



* Copyright / Permissions *

Authors may use this level as a base to build additional
levels.  



You MAY distribute this level, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.


* Where to get this level *

http://www.df-21.net