================================================================
Title                   : The Defection of Bez Kuahn
Filename                : DBK.ZIP
Author                  : DarthDoctor
Email Address           : Pretty much n/a - private message on df-21.net
Description             : I would highly advise reading Briefing.txt
			  It was too long to fit in game, so I really suggest it.

Additional Credits to   : Pretty much everyone in the Dark Forces editing community.
			  A lot of the stuff in here is custom, and I don't have 
			  all the credits handy. To quote a previous level,
			  "If there's something of yours in here, take a bow."
================================================================

* Play Information *

Level replaced          : None
Difficulty Settings     : Yes - Easy (shortened, gentler version)
			        Medium (The way it's meant to be played)
			        Hard (Unrealistically gruesome)
New BMs                 : Yes, but they've all been used before
New FMEs                : Yes, but "
New WAXs                : Yes, but " 
New 3DOs                : Yes, but "
New VOCs                : No
New GMDs                : No
New VUEs                : No
New Briefings           : Yes
New Cutscenes           : No

* Construction *

Base                    : From scratch - prolly worked on on and off for 4~5 years
Editor(s) used          : WDFUSE, BMPDF, PSP8, etc
Known Bugs              : There are a few minor HOMs in the wide outdoor areas,
			  yet I can't bring myself to change the geometry enough
			  to destroy them completely.
			* Leaving the contruction tunnel, a brief one to the east
			* Same area, river to the south
			* Door to the TIE base, facing NW, brief if walking
			* Northern ledge, if walking south. Completely avoided by
			  walking in the canyon.
			Also, there are two known other issues:
			* Sometimes the goal file won't update when you finish
			  with Bez. The rest of the level can be played normally,
			  there just won't be any "Mission complete" message.
			* There is a rare and nasty crash that will occassionally
			  pop up, after the first objective. I've tried everything
			  I can to eliminate it, and it is quite rare. I've never
			  observed it past the red key.
			And in case you were wondering, yes, there are parts that
			  are bug free :-P


* Copyright / Permissions *

Authors may use this level as a base to build additional levels, *provided* I am
contact prior.  


You MAY distribute this level, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact. Although, of course, how can you tell these are the unaltered
words of DarthDoctor?




* Where to get this level *
www.df-21.net

* Credits *
Custom WAXes:
Marv Mays
Kevin "Scape Goat" Buscemi
APWAX
There are a few other custom jobs in here, my cudos to their authors.

Other custom components:
Casey "xwing_original" Neumiller
TJ13
Patrick Haslow
Peter Klassen

I'd also like to nod to TIE Defender Base, a great level with a very inspirational atmosphere.

And a big nod to BB, XWO, JC, and, of course, good ol' Fenny - where would I be without ya guys?

* Interesting stats *
887.24DFU on the X axis
224.00DFU on the Y axis
1,402.08DFU on the Z axis
So this level would fit in a giant block of volume 278,651,846.8608 DFU^3

With 687 sectors and 6072 walls, the walls per sector are about 8.838
The largest sector is "southcaves" with an impressive 752 walls -
if it were not included, walls per sector would be only 7.755