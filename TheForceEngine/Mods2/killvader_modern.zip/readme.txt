IMPORTANT! If you have less than 16 MB of RAM, you may experience sound
loss and/or out-of-memory problems! It is highly recommended that you 
only play this level if you have 16 MB RAM or more.

Also, certain setups even with 16 MB of RAM may cause problems with the
level. Please try and free up as much memory as possible if you have any
problems, and try again. If you still have problems, try installing the
sound and texture GOB files.

Please also see the note about HOMs in the bugs section below.

=============================================================================
This level (including drawing the Vader) was begun in around October last 
year. I've spent ages on it, so I really hope you enjoy it!

The plan for my next level:

Kyle will have to infiltrate a stormtrooper training center on a moon of
Mytus VII, Stars End, where General Mohc's brother is conducting experiments 
on the new "invisible trooper".... (I've already started on it, but with all 
the schoolwork I'm getting, don't expect it anytime this year :-) )

=============================================================================
Please unzip all contents of this zip into your DARK\ directory for the level
to work properly. The batch file for running the level will check that you 
have done this correctly and will not load Dark Forces if a file is not 
present.

Note: Because the game engine takes files in the DARK\ directory in 
preference to files in a patch GOB, there cannot be any files in your DARK\
directory which have the same name as files in my GOB or they will be used
instead when called for. This can cause major problems when loading or 
running the level. The batch file will check for this and will not load 
Dark Forces if a conflicting file is present. You'll have to back up
and delete any such file if this happens.

=============================================================================
Title                   : Assassinate Darth Vader 
Filename                : KILVADER.GOB
Author                  : Jereth Kok
Email Address           : jereth@alphalink.com.au
Misc. Author Info       : Year 11 student in Melbourne, Australia.
			  
			  Just your average Star Wars/Sci Fi/ Computer game 
			  freak

Description             : A level set inside an Victory Star Destroyer
			  where you must find and assassinate Darth Vader
			  before planting a sequencer charge, then 
			  escape.


Additional Credits to   : 

George Lucas    --      Special thanks for the Star Wars universe.
LucasArts team  --      Thanks for Dark Forces, the best game of '94. Eagerly
			 awaiting Jedi Knight and X-Wing vs. TIE Fighter!
Yves Borckmans  --      Thanks for DFUSE, WDFUSE and many discussions about
			 almost everything.
Alexei Novikov  --      Thanks for BMPDF, which was used to compress all 
			 WAXes, FMEs and BMs. Thanks also for all the 
			 discussions, especially about the INF.
Carlos Gomez    --      Thanks for Cyra, Fmecad64 and 3DOshow.
Paul Nemesh     --      Thanks for the text on VUEs.
Peter Klassen   --      Thanks for the Vader VOCs extracted TIE Fighter and
			 Rebel Assault, as well as the dying one and the 
			 sabre swinging. Thanks also for touching up my 
			 original Vader cells, and for the briefing font.
Shane Johnson   --      Thanks for the Star Wars Technical Journal, which
			 helped me a lot in designing my level.
JASC            --      Thanks for Paintshop Pro, used to create the Bridge
			 viewport texture
David Johnston   --      Thanks for CoolEdit, used to mix and edit many of 
			 the sounds
Leonardo H.
 Loureiro       --      Thanks for LView Pro, used to create the briefing
			 and objective screen
All other       --      Thanks for the great inspiration, ideas and
 level creators          motivation.

Thanks to the guy who drew the medical droid and bacta tank frames - sorry
I don't know your name :-)

Beta testers:
	Yves Borckmans
	Elwyn Chow
	Ole Thomasen
	Glenn Edmiston
	Doug Vadar
	Peter Klassen

      Thank you all for your comments and help on getting rid of problems.
=============================================================================

* Play Information *

Level(s) replaced       : none
Difficulty Settings     : No - only setting is equivilant of normal
New BMs                 : Yes - the Bridge window
New FMEs                : Yes - bacta tank and med droid from Bespin
New WAXs                : Yes - Vader!!!
New 3DOs                : Yes - Repulsor platform
New VOCs                : Yes - Vader ones, and some others
New GMDs                : No - just patched the secbase music with executor
			       music (which sounds better!)
New VUEs                : Yes - Shuttle, 4 TIEs and Kyle's ship
New Briefings           : Yes
New Cutscenes           : No


* Level Information (brought to you by WDFUSE's statistics option!) *

Sectors                 --      896
Vertices / Walls        --      6204
Objects                 --      820

Textures                --      178
Sprites                 --      25
Frames                  --      26
Pods                    --      10
Sounds                  --      1

INF items               --      155


* Construction *

Base                    : New level from scratch
Editor(s) used          : DFUSE 1.00, WDFUSE 1.50, WDFUSE 1.666, and many
			  beta releases of WDFUSE 2.00.

Known Bugs              :

Minor HOM effects in the hangar bay and when looking out onto the exterior 
of the Star Destroyer. This is due to an unfortunate limitation of the game 
engine -- large and complex sectors seem to cause overflows and result in 
the HOMs. I tried to split as many walls as I could in these areas in order
to minimise this problem.

NOTE: If you find the HOMs particularly severe on your system, try shrinking 
the screen size as this will reduce them.

Please mail me if you find any other bugs


* Copyright / Permissions *

Authors MAY use this level as a base to build additional levels. Please
ask my permission first and give due credit.

You MAY distribute this level, provided you include this file, with
no modifications.  You may distribute this file in any electronic
format (BBS, Diskette, CD, etc) as long as you include this file 
intact.

Distribution must be FREE OF CHARGE.


* Where to get this level *

Well, if you're reading this then you've obviously already found it!!! :-)
